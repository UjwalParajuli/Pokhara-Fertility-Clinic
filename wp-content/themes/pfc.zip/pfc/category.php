<?php
     echo category_description( get_category_by_slug( 'donor' )->term_id ); 

?>